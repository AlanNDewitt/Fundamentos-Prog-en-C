/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    int bolado;
    int x;
    printf(" \n * Hola BRO            *");
    printf(" \n * jueguemos un volado *");
    printf(" \n * que escoges         *");
    printf(" \n * CARA o SOL          *");
    printf(" \n *   1     2           *");
    scanf("%d",&bolado);
    
    srand(time(NULL));
    x=rand()%3;
    
    if (  bolado == 1)  
    {
       
       if (x==1){printf("ganaste");}
       else {printf("perdiste");}
       
    }
    
    
    if (  bolado == 2)  
    {
        if (x==0){printf("GANASTE");}
        else{printf("Perdiste");}
    }
    
    if ( x == 0) {printf("\nCALLO SOL");}
    if ( x == 1){printf("\nCALLO CARA");}
    if (x == 2){printf("\nCALLO Parada la moneda jaja");}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    printf("\n %d",x);
}
